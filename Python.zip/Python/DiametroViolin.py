import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Cargar el archivo Excel con la ruta correcta
df = pd.read_excel('C:/Users/heavy/OneDrive/Desktop/Sujeto4ojos.xlsx')

# Asegurarse de que la columna 'Tiempo' esté en formato de texto
df['Tiempo'] = df['Tiempo'].astype(str)

# Verificar si todos los valores de 'Tiempo' están en el formato HH:MM:SS
df = df[df['Tiempo'].str.match(r'^\d{2}:\d{2}:\d{2}$')]

# Convertir la columna 'Tiempo' a formato de hora (HH:MM:SS) sin fechas
df['Tiempo'] = pd.to_timedelta(df['Tiempo'].apply(lambda x: f'0 days {x}'))

# Extraer las horas, minutos y segundos
df['Tiempo'] = df['Tiempo'].apply(lambda x: str(x).split(' ')[-1])  # Obtiene HH:MM:SS

# Dividir el DataFrame en subgrupos según la columna 'rango'
rango1 = df[df['rango'] == 1]
rango2 = df[df['rango'] == 2]
rango3 = df[df['rango'] == 3]

# Filtrar los valores de diámetro fuera de un rango lógico (por ejemplo, mayor a 150 píxeles)
max_valor = 400
rango1 = rango1[rango1['DiamDer'] <= max_valor]
rango2 = rango2[rango2['DiamDer'] <= max_valor]
rango3 = rango3[rango3['DiamDer'] <= max_valor]

rango1 = rango1[rango1['DiamIzq'] <= max_valor]
rango2 = rango2[rango2['DiamIzq'] <= max_valor]
rango3 = rango3[rango3['DiamIzq'] <= max_valor]

# Función para generar los gráficos de violín y dispersión para los diámetros izquierdo y derecho
def generar_violin_y_scatter(df_rango1, df_rango2, df_rango3):
    # Crear una nueva columna 'rango' para concatenar los tres rangos
    df_rango1['rango'] = 'Rango 1'
    df_rango2['rango'] = 'Rango 2'
    df_rango3['rango'] = 'Rango 3'

    # Concatenar todos los datos
    df_completo = pd.concat([df_rango1[['rango', 'DiamIzq', 'DiamDer']], 
                             df_rango2[['rango', 'DiamIzq', 'DiamDer']], 
                             df_rango3[['rango', 'DiamIzq', 'DiamDer']]])

    # Definir colores personalizados para los violines
    violín_paleta_izq = ['#BB8FCE', '#76D7C4', '#BB8FCE']
    violín_paleta_der = ['#BB8FCE', '#76D7C4', '#BB8FCE']

    # Crear la figura para los gráficos de violín y dispersión
    fig, axes = plt.subplots(1, 2, figsize=(18, 6))

    # Gráfico de violín y dispersión para el diámetro izquierdo
    sns.violinplot(x='rango', y='DiamIzq', data=df_completo, inner='box', ax=axes[0], palette=violín_paleta_izq)
    axes[0].scatter(rango1['rango'], rango1['DiamIzq'], color='#FF6347', alpha=0.6, label='Rango 1', marker='o')
    axes[0].scatter(rango2['rango'], rango2['DiamIzq'], color='#4682B4', alpha=0.6, label='Rango 2', marker='o')
    axes[0].scatter(rango3['rango'], rango3['DiamIzq'], color='#32CD32', alpha=0.6, label='Rango 3', marker='o')
    axes[0].set_title('Violin Plot y Dispersión de Diámetro Izquierdo')
    axes[0].set_xlabel('Rango')
    axes[0].set_ylabel('Diámetro Izquierdo')
    axes[0].set_ylim(-20, 400)  # Establecer límites para el eje y

    # Gráfico de violín y dispersión para el diámetro derecho
    sns.violinplot(x='rango', y='DiamDer', data=df_completo, inner='box', ax=axes[1], palette=violín_paleta_der)
    axes[1].scatter(rango1['rango'], rango1['DiamDer'], color='#FFD700', alpha=0.6, label='Rango 1', marker='o')
    axes[1].scatter(rango2['rango'], rango2['DiamDer'], color='#8A2BE2', alpha=0.6, label='Rango 2', marker='o')
    axes[1].scatter(rango3['rango'], rango3['DiamDer'], color='#FF4500', alpha=0.6, label='Rango 3', marker='o')
    axes[1].set_title('Violin Plot y Dispersión de Diámetro Derecho')
    axes[1].set_xlabel('Rango')
    axes[1].set_ylabel('Diámetro Derecho')
    axes[1].set_ylim(-20, 400)  # Establecer límites para el eje y

    # Ajustar espacio entre subgráficos
    plt.tight_layout()

    # Mostrar los gráficos
    plt.show()

# Llamadas a las funciones para generar los gráficos
generar_violin_y_scatter(rango1, rango2, rango3)
