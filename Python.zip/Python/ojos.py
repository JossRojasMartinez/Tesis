import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Cargar el archivo Excel 
df = pd.read_excel('C:/Users/heavy/OneDrive/Desktop/Sujeto4ojos.xlsx')

# Columna 'Tiempo'  en formato de texto
df['Tiempo'] = df['Tiempo'].astype(str)

# Valores de 'Tiempo'  en  formato HH:MM:SS
df = df[df['Tiempo'].str.match(r'^\d{2}:\d{2}:\d{2}$')]

# Columna 'Tiempo' a formato de hora (HH:MM:SS) sin fechas
df['Tiempo'] = pd.to_timedelta(df['Tiempo'].apply(lambda x: f'0 days {x}'))

# Extraer  horas, minutos y segundos
df['Tiempo'] = df['Tiempo'].apply(lambda x: str(x).split(' ')[-1])  # Obtiene HH:MM:SS

# Dividir  en subgrupos según la columna 'rango'
rango1 = df[df['rango'] == 1]
rango2 = df[df['rango'] == 2]
rango3 = df[df['rango'] == 3]

# Filtrar los valores de diámetro 
max_valor = 400
rango1 = rango1[rango1['DiamDer'] <= max_valor]
rango2 = rango2[rango2['DiamDer'] <= max_valor]
rango3 = rango3[rango3['DiamDer'] <= max_valor]

rango1 = rango1[rango1['DiamIzq'] <= max_valor]
rango2 = rango2[rango2['DiamIzq'] <= max_valor]
rango3 = rango3[rango3['DiamIzq'] <= max_valor]

# Etiquetas del eje X
def ajustar_etiquetas_eje_x(ax):
    xticks = ax.get_xticks()
    step = max(1, len(xticks) // 10)  
    ax.set_xticks(xticks[::step])
    ax.tick_params(axis='x', rotation=45)  

# Gráficos de posiciones X
def generar_graficos_posicion_x(rango1, rango2, rango3):
    fig, axes = plt.subplots(1, 2, figsize=(14, 6))

    
    color_rango1 = '#FF6347'  
    color_rango2 = '#4682B4'  
    color_rango3 = '#32CD32'  

    labels = ['Antes', 'Decisión', 'Después']

    # Gráfico de dispersión de las posiciones horizontales (IzqPosX)
    axes[0].scatter(rango1['Tiempo'], rango1['IzqPosX'], color=color_rango1, alpha=0.5, label=labels[0])
    axes[0].scatter(rango2['Tiempo'], rango2['IzqPosX'], color=color_rango2, alpha=0.5, label=labels[1])
    axes[0].scatter(rango3['Tiempo'], rango3['IzqPosX'], color=color_rango3, alpha=0.5, label=labels[2])
    axes[0].set_title(f'Ojo Izquierdo')
    axes[0].set_xlabel('Tiempo')
    axes[0].set_ylabel('Posición Izquierda X')
    axes[0].legend()
    ajustar_etiquetas_eje_x(axes[0])
    axes[0].set_ylim(-20, 1200)  

    # Gráfico de dispersión de las posiciones horizontales (DerPosX)
    axes[1].scatter(rango1['Tiempo'], rango1['DerPosX'], color=color_rango1, alpha=0.5, label=labels[0])
    axes[1].scatter(rango2['Tiempo'], rango2['DerPosX'], color=color_rango2, alpha=0.5, label=labels[1])
    axes[1].scatter(rango3['Tiempo'], rango3['DerPosX'], color=color_rango3, alpha=0.5, label=labels[2])
    axes[1].set_title(f' Ojo Derecho')
    axes[1].set_xlabel('Tiempo')
    axes[1].set_ylabel('Posición Derecha X')
    axes[1].legend()
    ajustar_etiquetas_eje_x(axes[1])
    axes[1].set_ylim(-20, 1200)  

    plt.tight_layout()
    plt.show()

# Gráficos de posiciones Y
def generar_graficos_posicion_y(rango1, rango2, rango3):
    fig, axes = plt.subplots(1, 2, figsize=(14, 6))

    
    color_rango1 = '#FF6347'  
    color_rango2 = '#4682B4'  
    color_rango3 = '#32CD32'  

    labels = ['Antes', 'Decisión', 'Después']

    # Gráfico de dispersión de las posiciones verticales (IzqPosY)
    axes[0].scatter(rango1['Tiempo'], rango1['IzqPosY'], color=color_rango1, alpha=0.5, label=labels[0])
    axes[0].scatter(rango2['Tiempo'], rango2['IzqPosY'], color=color_rango2, alpha=0.5, label=labels[1])
    axes[0].scatter(rango3['Tiempo'], rango3['IzqPosY'], color=color_rango3, alpha=0.5, label=labels[2])
    axes[0].set_title(f'Ojo Izquierdo')
    axes[0].set_xlabel('Tiempo')
    axes[0].set_ylabel('Posición Izquierda Y')
    axes[0].legend()
    ajustar_etiquetas_eje_x(axes[0])
    axes[0].set_ylim(-20, 500)  

    # Gráfico de dispersión de las posiciones verticales (DerPosY)
    axes[1].scatter(rango1['Tiempo'], rango1['DerPosY'], color=color_rango1, alpha=0.5, label=labels[0])
    axes[1].scatter(rango2['Tiempo'], rango2['DerPosY'], color=color_rango2, alpha=0.5, label=labels[1])
    axes[1].scatter(rango3['Tiempo'], rango3['DerPosY'], color=color_rango3, alpha=0.5, label=labels[2])
    axes[1].set_title(f'Ojo Derecho')
    axes[1].set_xlabel('Tiempo')
    axes[1].set_ylabel('Posición Derecha Y')
    axes[1].legend()
    ajustar_etiquetas_eje_x(axes[1])
    axes[1].set_ylim(-20, 500)  

    plt.tight_layout()
    plt.show()

# Gráficos de diámetro vs tiempo
def generar_graficos_diametro_vs_tiempo(rango1, rango2, rango3):
    fig, axes = plt.subplots(1, 2, figsize=(14, 6))

    
    color_rango1 = '#FF6347'  
    color_rango2 = '#4682B4' 
    color_rango3 = '#32CD32'  

    labels = ['Antes', 'Decisión', 'Después']

    # Gráfico de dispersión de diámetro izquierdo (DiamIzq)
    axes[0].scatter(rango1['Tiempo'], rango1['DiamIzq'], color=color_rango1, alpha=0.5, label=labels[0])
    axes[0].scatter(rango2['Tiempo'], rango2['DiamIzq'], color=color_rango2, alpha=0.5, label=labels[1])
    axes[0].scatter(rango3['Tiempo'], rango3['DiamIzq'], color=color_rango3, alpha=0.5, label=labels[2])
    axes[0].set_title(f'Ojo Izquierdo')
    axes[0].set_xlabel('Tiempo')
    axes[0].set_ylabel('Diámetro Izquierdo')
    axes[0].legend()
    ajustar_etiquetas_eje_x(axes[0])
    axes[0].set_ylim(-10, 400) 

    # Gráfico de dispersión de diámetro derecho (DiamDer)
    axes[1].scatter(rango1['Tiempo'], rango1['DiamDer'], color=color_rango1, alpha=0.5, label=labels[0])
    axes[1].scatter(rango2['Tiempo'], rango2['DiamDer'], color=color_rango2, alpha=0.5, label=labels[1])
    axes[1].scatter(rango3['Tiempo'], rango3['DiamDer'], color=color_rango3, alpha=0.5, label=labels[2])
    axes[1].set_title(f'Ojo Derecho')
    axes[1].set_xlabel('Tiempo')
    axes[1].set_ylabel('Diámetro Derecho')
    axes[1].legend()
    ajustar_etiquetas_eje_x(axes[1])
    axes[1].set_ylim(-10, 400)  

    
    plt.tight_layout()
    plt.show()

# Generar los gráficos
generar_graficos_posicion_x(rango1, rango2, rango3)
generar_graficos_posicion_y(rango1, rango2, rango3)
generar_graficos_diametro_vs_tiempo(rango1, rango2, rango3)



